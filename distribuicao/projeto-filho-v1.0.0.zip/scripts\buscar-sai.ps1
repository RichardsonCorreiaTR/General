﻿# buscar-sai.ps1 (wrapper para projeto filho)
# Redireciona para o script original no OneDrive.
# IMPORTANTE: Rodar em terminal SEPARADO (fora do Cursor)
#
# Exemplos:
#   .\scripts\buscar-sai.ps1 -Termo "INSS"
#   .\scripts\buscar-sai.ps1 -Termo "ferias" -Tipo NE -Pendentes
#   .\scripts\buscar-sai.ps1 -SAI 12345

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$projetoDir = Split-Path -Parent $scriptDir

$caminhosFile = Join-Path $projetoDir "config\caminhos.json"
if (Test-Path $caminhosFile) {
    $caminhos = Get-Content $caminhosFile -Raw | ConvertFrom-Json
    $onedriveBase = $caminhos.onedrive_base
} else {
    $onedriveBase = ""
}

$scriptOriginal = ""
if ($onedriveBase -and (Test-Path (Join-Path $onedriveBase "scripts\buscar-sai.ps1"))) {
    $scriptOriginal = Join-Path $onedriveBase "scripts\buscar-sai.ps1"
}

if (-not $scriptOriginal) {
    $refDir = Join-Path $projetoDir "referencia\banco-dados"
    $parentRef = Split-Path -Parent (Split-Path -Parent $refDir)
    $tentativa = Join-Path (Split-Path -Parent $refDir) "..\scripts\buscar-sai.ps1"
    if (Test-Path (Join-Path $projetoDir "referencia\banco-dados\dados-brutos")) {
        Write-Host "Dados encontrados via referencia/. Redirecionando..." -ForegroundColor Cyan
        $env:BUSCAR_SAI_DADOS_DIR = Join-Path $projetoDir "referencia\banco-dados\dados-brutos"
    }
}

if ($scriptOriginal) {
    & $scriptOriginal @args
} else {
    Write-Host "=== Busca de SAIs ===" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "ERRO: Script original nao encontrado." -ForegroundColor Red
    Write-Host ""
    Write-Host "Opcao 1: Rodar direto na pasta do OneDrive:" -ForegroundColor Yellow
    Write-Host "  cd `"$onedriveBase`"" -ForegroundColor White
    Write-Host "  .\scripts\buscar-sai.ps1 -Termo `"seu termo`"" -ForegroundColor White
    Write-Host ""
    Write-Host "Opcao 2: Verificar config/caminhos.json (onedrive_base)" -ForegroundColor Yellow
}
