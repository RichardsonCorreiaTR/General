# Guia de Configuracao Inicial -- Projeto Filho

## Instalacao Automatica (Recomendado)

O gerente vai te enviar o instalador. Rode em um terminal PowerShell:

```
Set-ExecutionPolicy Bypass -Scope Process
.\scripts\instalar-projeto-filho.ps1
```

O instalador faz tudo automaticamente:
1. Verifica pre-requisitos (Cursor, OneDrive, Git)
2. Cria a estrutura em `C:\CursorFolha\projeto-filho\`
3. Pede seu nome e email
4. Sincroniza OneDrive
5. Cria links para a base de dados
6. Baixa o codigo-fonte do sistema
7. Verifica se tudo esta OK
8. Abre o Cursor

## Instalacao Manual (se o instalador falhar)

### Pre-requisitos

- [ ] Cursor instalado (https://cursor.sh)
- [ ] OneDrive configurado e sincronizando
- [ ] Acesso ao SharePoint do CursorFolha
- [ ] Git instalado (https://git-scm.com) -- opcional

### Passo 1 -- Copiar o projeto

Copie toda a pasta `projeto-filho/` para `C:\CursorFolha\projeto-filho\`.

### Passo 2 -- Configurar sua identificacao

Edite `config/analista.json`:

```json
{
  "nome": "Seu Nome Completo",
  "email": "seu.email@thomsonreuters.com",
  "data_setup": "2026-03-04",
  "versao_instalada": "1.0.0",
  "onboarding_completo": false
}
```

### Passo 3 -- Configurar caminhos

Edite `config/caminhos.json` com seus paths:

```json
{
  "projeto_local": "C:\\CursorFolha\\projeto-filho",
  "codigo_local": "C:\\CursorFolha\\codigo-sistema\\versao-atual",
  "onedrive_base": "C:\\Users\\SEU-USUARIO\\Thomson Reuters Incorporated\\CursorFolha - General",
  "onedrive_logs": "C:\\Users\\SEU-USUARIO\\Thomson Reuters Incorporated\\CursorFolha - General\\logs\\analistas\\seu-nome"
}
```

### Passo 4 -- Sincronizar OneDrive

1. Abra o SharePoint: https://trten.sharepoint.com/sites/CursorFolha
2. Sincronize a pasta `General`
3. Ela aparecera em: `C:\Users\{seu-usuario}\Thomson Reuters Incorporated\CursorFolha - General`

### Passo 5 -- Criar links simbolicos

Abra PowerShell e rode:

```
cd "C:\CursorFolha\projeto-filho\referencia"
cmd /c mklink /J "banco-dados" "C:\Users\{seu-usuario}\Thomson Reuters Incorporated\CursorFolha - General\banco-dados"
cmd /c mklink /J "logs" "C:\Users\{seu-usuario}\Thomson Reuters Incorporated\CursorFolha - General\logs\analistas\{seu-nome-kebab}"
```

### Passo 6 -- Abrir no Cursor

1. Abra o Cursor
2. File -> Open Folder -> selecione `C:\CursorFolha\projeto-filho\`
3. As regras da IA carregam automaticamente
4. A IA iniciara o wizard de onboarding

## Verificacao

Rode para confirmar que tudo esta OK:

```
.\scripts\verificar-ambiente.ps1
```

## Atualizacao

Para atualizar o projeto quando o gerente publicar nova versao:

```
.\scripts\atualizar-projeto.ps1
```

## Buscar SAIs

Em terminal separado (fora do Cursor):

```
cd "C:\Users\{seu-usuario}\Thomson Reuters Incorporated\CursorFolha - General"
powershell -File scripts\buscar-sai.ps1 -Termo "INSS"
```
