# verificar-ambiente.ps1 (Projeto Filho)
# Valida todos os componentes do ambiente do analista.
# Gera relatorio colorido + config/status-ambiente.json

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$projetoDir = Split-Path -Parent $scriptDir

Write-Host ""
Write-Host "  =============================================" -ForegroundColor Cyan
Write-Host "  |   Verificacao de Ambiente - Folha           |" -ForegroundColor Cyan
Write-Host "  =============================================" -ForegroundColor Cyan
Write-Host ""

$checks = @()

function Add-Check($nome, $ok, $detalhe, $nivel) {
    if (-not $nivel) { $nivel = "obrigatorio" }
    $script:checks += @{ nome = $nome; ok = $ok; detalhe = $detalhe; nivel = $nivel }
    if ($ok) { Write-Host "  [OK] $nome" -ForegroundColor Green }
    elseif ($nivel -eq "opcional") { Write-Host "  [!]  $nome - $detalhe" -ForegroundColor DarkYellow }
    else { Write-Host "  [X]  $nome - $detalhe" -ForegroundColor Red }
}

# 1. Cursor
$cursorCmd = Get-Command cursor -ErrorAction SilentlyContinue
if ($cursorCmd) {
    Add-Check "Cursor instalado" $true $cursorCmd.Source
} else {
    $cursorAlt = @(
        "$env:LOCALAPPDATA\Programs\cursor\resources\app\bin\cursor.cmd",
        "$env:LOCALAPPDATA\cursor\cursor.exe"
    ) | Where-Object { Test-Path $_ } | Select-Object -First 1
    Add-Check "Cursor instalado" ([bool]$cursorAlt) "Nao encontrado em PATH"
}

# 2. Git
$gitCmd = Get-Command git -ErrorAction SilentlyContinue
Add-Check "Git instalado" ([bool]$gitCmd) "Instale em https://git-scm.com"

# 3. OneDrive rodando
$odProc = Get-Process OneDrive -ErrorAction SilentlyContinue
Add-Check "OneDrive rodando" ([bool]$odProc) "Inicie o OneDrive"

# 4. Config analista.json
$analistaFile = Join-Path $projetoDir "config\analista.json"
$analistaOK = $false
if (Test-Path $analistaFile) {
    $analista = Get-Content $analistaFile -Raw | ConvertFrom-Json
    $analistaOK = [bool]$analista.nome -and [bool]$analista.email
}
Add-Check "config/analista.json preenchido" $analistaOK "Preencha nome e email"

# 5. Config caminhos.json
$caminhosFile = Join-Path $projetoDir "config\caminhos.json"
$caminhosOK = $false
if (Test-Path $caminhosFile) {
    $caminhos = Get-Content $caminhosFile -Raw | ConvertFrom-Json
    $caminhosOK = [bool]$caminhos.onedrive_base
}
Add-Check "config/caminhos.json configurado" $caminhosOK "Rode o instalador"

# 6. VERSION.json
$versionFile = Join-Path $projetoDir "config\VERSION.json"
$versionOK = Test-Path $versionFile
$versaoAtual = ""
if ($versionOK) { $versaoAtual = (Get-Content $versionFile -Raw | ConvertFrom-Json).versao }
Add-Check "config/VERSION.json (v$versaoAtual)" $versionOK "Arquivo ausente"

# 7. OneDrive sincronizado
$onedriveOK = $false
$onedrivePath = ""
if ($caminhosOK) {
    $onedrivePath = $caminhos.onedrive_base
    $onedriveOK = (Test-Path $onedrivePath) -and (Test-Path (Join-Path $onedrivePath "banco-dados"))
}
Add-Check "OneDrive sincronizado" $onedriveOK "Pasta nao encontrada: $onedrivePath"

# 8. Symlink banco-dados
$refBD = Join-Path $projetoDir "referencia\banco-dados"
$symlinkBDOK = Test-Path $refBD
Add-Check "referencia/banco-dados (symlink)" $symlinkBDOK "Crie o symlink para o OneDrive"

# 9. Symlink logs
$refLogs = Join-Path $projetoDir "referencia\logs"
$symlinkLogsOK = Test-Path $refLogs
Add-Check "referencia/logs (symlink)" $symlinkLogsOK "Crie o symlink para logs no OneDrive"

# 10. Templates presentes
$templatesDir = Join-Path $projetoDir "templates"
$templatesOK = $false
$nTemplates = 0
if (Test-Path $templatesDir) {
    $nTemplates = (Get-ChildItem $templatesDir -Filter "TEMPLATE-*.md" | Measure-Object).Count
    $templatesOK = $nTemplates -ge 4
}
Add-Check "Templates presentes ($nTemplates/4)" $templatesOK "Templates ausentes"

# 11. Regras .cursor/rules
$rulesDir = Join-Path $projetoDir ".cursor\rules"
$rulesOK = $false
$nRules = 0
if (Test-Path $rulesDir) {
    $nRules = (Get-ChildItem $rulesDir -Filter "*.mdc" | Measure-Object).Count
    $rulesOK = $nRules -ge 3
}
Add-Check "Regras IA ($nRules .mdc)" $rulesOK "Regras ausentes"

# 12. Codigo-fonte local (com fallback legado)
$codigoOK = $false
$codigoPath = ""
if ($caminhosOK) {
    $codigoPath = $caminhos.codigo_local
    if (-not (Test-Path $codigoPath)) {
        $legado = Join-Path $env:USERPROFILE "FolhaSDD-dados-pesados\versao-atual"
        if (Test-Path $legado) {
            $codigoPath = $legado
            Write-Host "  [i]  Codigo encontrado no caminho legado: $legado" -ForegroundColor DarkYellow
        }
    }
    if (Test-Path $codigoPath) {
        $nArqs = (Get-ChildItem $codigoPath -File -Recurse -ErrorAction SilentlyContinue | Measure-Object).Count
        $codigoOK = $nArqs -gt 100
    }
}
Add-Check "Codigo-fonte local ($codigoPath)" $codigoOK "Rode: .\scripts\atualizar-codigo.ps1"

# 12b. Indice de arquivos
$indiceArquivosOK = $false
$indiceArquivosPath = Join-Path $projetoDir "referencia\banco-dados\mapa-sistema\indice-arquivos.md"
if (Test-Path $indiceArquivosPath) { $indiceArquivosOK = $true }
Add-Check "Indice de arquivos (mapa-sistema)" $indiceArquivosOK "O gerente precisa rodar: scripts\gerar-indice-codigo.ps1" "opcional"

# 13. ODBC - Driver SQL Anywhere
$odbcDriverOK = $false
$odbcDriver = Get-OdbcDriver -ErrorAction SilentlyContinue | Where-Object { $_.Name -like "*SQL Anywhere*" } | Select-Object -First 1
if ($odbcDriver) { $odbcDriverOK = $true }
Add-Check "ODBC driver SQL Anywhere" $odbcDriverOK "Instale o driver SQL Anywhere 9.0 (peca ao time de infra)" "opcional"

# 14. ODBC - DSN pbcvs9
$odbcDsnOK = $false
$odbcDsn = Get-OdbcDsn -ErrorAction SilentlyContinue | Where-Object { $_.Name -like "*pbcvs*" } | Select-Object -First 1
if ($odbcDsn) { $odbcDsnOK = $true }
Add-Check "ODBC DSN pbcvs9" $odbcDsnOK "Rode: .\scripts\setup-odbc.ps1 -Verificar (ou configure manualmente)" "opcional"

# 15. Versao atualizada
$versaoAtualizadaOK = $true
if ($caminhosOK -and $onedrivePath) {
    $ultimaVDir = Join-Path $onedrivePath "distribuicao\ultima-versao\config\VERSION.json"
    if (Test-Path $ultimaVDir) {
        $ultimaVersao = (Get-Content $ultimaVDir -Raw | ConvertFrom-Json).versao
        $versaoAtualizadaOK = $versaoAtual -eq $ultimaVersao
        if (-not $versaoAtualizadaOK) {
            Write-Host "  [!] Versao disponivel: v$ultimaVersao (atual: v$versaoAtual)" -ForegroundColor DarkYellow
        }
    }
}
Add-Check "Versao atualizada" $versaoAtualizadaOK "Rode: .\scripts\atualizar-projeto.ps1"

# Resumo
Write-Host ""
Write-Host ("-" * 50) -ForegroundColor DarkGray
$obrigatorios = $checks | Where-Object { $_.nivel -ne "opcional" }
$opcionais = $checks | Where-Object { $_.nivel -eq "opcional" }
$obrigOK = ($obrigatorios | Where-Object { $_.ok }).Count
$opcOK = ($opcionais | Where-Object { $_.ok }).Count
$totalOK = ($checks | Where-Object { $_.ok }).Count
$total = $checks.Count

$cor = if ($obrigOK -eq $obrigatorios.Count) { "Green" } elseif ($obrigOK -ge ($obrigatorios.Count - 2)) { "Yellow" } else { "Red" }
Write-Host "  Obrigatorios: $obrigOK/$($obrigatorios.Count) OK" -ForegroundColor $cor
Write-Host "  Opcionais:    $opcOK/$($opcionais.Count) OK" -ForegroundColor $(if ($opcOK -eq $opcionais.Count) { "Green" } else { "DarkYellow" })
Write-Host "  Total:        $totalOK/$total" -ForegroundColor $cor

if ($totalOK -lt $total) {
    $falhasObrig = $obrigatorios | Where-Object { -not $_.ok }
    $falhasOpc = $opcionais | Where-Object { -not $_.ok }
    if ($falhasObrig.Count -gt 0) {
        Write-Host ""
        Write-Host "  Itens pendentes (obrigatorios):" -ForegroundColor Red
        $falhasObrig | ForEach-Object { Write-Host "    - $($_.nome): $($_.detalhe)" -ForegroundColor Red }
    }
    if ($falhasOpc.Count -gt 0) {
        Write-Host ""
        Write-Host "  Itens pendentes (opcionais):" -ForegroundColor DarkYellow
        $falhasOpc | ForEach-Object { Write-Host "    - $($_.nome): $($_.detalhe)" -ForegroundColor DarkYellow }
    }
}

# Salvar status
$statusFile = Join-Path $projetoDir "config\status-ambiente.json"
$status = @{
    verificadoEm = (Get-Date -Format "yyyy-MM-ddTHH:mm:ss")
    versao = $versaoAtual
    totalChecks = $total
    checksOK = $totalOK
    obrigatoriosOK = $obrigOK
    obrigatoriosTotal = $obrigatorios.Count
    opcionaisOK = $opcOK
    opcionaisTotal = $opcionais.Count
    resultado = if ($obrigOK -eq $obrigatorios.Count) { "OK" } elseif ($obrigOK -ge ($obrigatorios.Count - 2)) { "PARCIAL" } else { "FALHA" }
    detalhes = $checks | ForEach-Object { @{ nome = $_.nome; ok = $_.ok; detalhe = $_.detalhe; nivel = $_.nivel } }
} | ConvertTo-Json -Depth 3
Set-Content -Path $statusFile -Value $status -Encoding UTF8

Write-Host ""
Write-Host "  Status salvo em: config/status-ambiente.json" -ForegroundColor Gray
Write-Host ""
