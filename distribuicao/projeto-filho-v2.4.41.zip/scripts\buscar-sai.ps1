# buscar-sai.ps1
# Busca SAIs/PSAIs nos JSONs fracionados (arquivos leves por tipo+status).
# Se especificar -Tipo e/ou -Pendentes, carrega apenas o arquivo relevante.
#
# COMPORTAMENTO PADRAO: Busca nos PSAIs (campos completos com BLOBs), mas
# agrupa por SAI e mostra apenas a PSAI mais recente de cada SAI. Isso evita
# duplicidade quando uma PSAI ja tem SAI gerada. Use -VerPSAIs para ver todas.
#
# IMPORTANTE: Rodar em terminal SEPARADO (fora do Cursor)
#
# Exemplos:
#   .\buscar-sai.ps1 -Termo "INSS"
#   .\buscar-sai.ps1 -Termo "ferias" -Tipo NE -Pendentes
#   .\buscar-sai.ps1 -SAI 12345
#   .\buscar-sai.ps1 -Termo "rescisao" -VerPSAIs
#   .\buscar-sai.ps1 -Termo "sped" -Modulo "Escrita"
#   .\buscar-sai.ps1 -Termo "FGTS" -Resumido -Max 50

param(
    [string]$Termo = "",
    [string[]]$Termos = @(),
    [switch]$PalavraIsolada,
    [switch]$SomenteDescricao,
    [int]$SAI = 0,
    [int]$PSAI = 0,
    [string]$Tipo = "",
    [string]$Modulo = "",
    [string[]]$Areas = @(),
    [switch]$Pendentes,
    [switch]$VerPSAIs,
    [switch]$VisualizarSai,
    [switch]$Resumido,
    [int]$Max = 30
)

# URLs internas do SGSAI/SGD (clicaveis via Ctrl+Click no terminal)
# Ajustar aqui se o dominio/path mudar.
$URL_SAI_BASE  = "https://sgsai.dominiosistemas.com.br/sgsai/faces/sai.html?sai="
$URL_PSAI_BASE = "https://sgd.dominiosistemas.com.br/sgsa/faces/psai.html?psai="

function SafeStr($v) { if ($null -eq $v) { return "" }; return [string]$v }

# Remove acentos para comparacao tolerante: "Contábil" -> "Contabil"
function Remove-Acentos {
    param([string]$s)
    if (-not $s) { return "" }
    $normalizado = $s.Normalize([System.Text.NormalizationForm]::FormD)
    $sb = New-Object System.Text.StringBuilder
    foreach ($c in $normalizado.ToCharArray()) {
        $cat = [System.Globalization.CharUnicodeInfo]::GetUnicodeCategory($c)
        if ($cat -ne [System.Globalization.UnicodeCategory]::NonSpacingMark) {
            [void]$sb.Append($c)
        }
    }
    return $sb.ToString().Normalize([System.Text.NormalizationForm]::FormC)
}

function Get-UrlSai($numero) {
    $n = 0; if ([int]::TryParse([string]$numero, [ref]$n) -and $n -gt 0) { return "$URL_SAI_BASE$n" } else { return "" }
}
function Get-UrlPsai($numero) {
    $n = 0; if ([int]::TryParse([string]$numero, [ref]$n) -and $n -gt 0) { return "$URL_PSAI_BASE$n" } else { return "" }
}

function Test-NumeroSaiPsai($reg, [string]$numStr) {
    $num = 0
    if (-not [int]::TryParse($numStr.Trim(), [ref]$num) -or $num -le 0) { return $false }
    $sai = 0; [void][int]::TryParse([string]$reg.i_sai, [ref]$sai)
    $psai = 0; [void][int]::TryParse([string]$reg.i_psai, [ref]$psai)
    return ($sai -eq $num -or $psai -eq $num)
}

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$projetoDir = Split-Path -Parent $scriptDir
if ($env:BUSCAR_SAI_DADOS_DIR -and (Test-Path $env:BUSCAR_SAI_DADOS_DIR)) {
    $dadosBrutosDir = $env:BUSCAR_SAI_DADOS_DIR
} else {
    $dadosBrutosDir = Join-Path $projetoDir "banco-dados\dados-brutos"
    # Fallback para projeto-filho onde os dados ficam em referencia\banco-dados\dados-brutos (symlink OneDrive)
    if (-not (Test-Path (Join-Path $dadosBrutosDir "psai"))) {
        $referenciaDir = Join-Path $projetoDir "referencia\banco-dados\dados-brutos"
        if (Test-Path (Join-Path $referenciaDir "psai")) {
            $dadosBrutosDir = $referenciaDir
        }
    }
}
$psaiDir = Join-Path $dadosBrutosDir "psai"
$saiDir = Join-Path $dadosBrutosDir "sai"
$cacheCompleto = Join-Path $dadosBrutosDir "sai-psai-escrita.json"

if (-not $Termo -and $Termos.Count -eq 0 -and $SAI -eq 0 -and $PSAI -eq 0 -and -not $Modulo -and $Areas.Count -eq 0) {
    Write-Host "=== Busca de SAIs/PSAIs ===" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Uso:" -ForegroundColor White
    Write-Host "  .\buscar-sai.ps1 -Termo 'palavra'                Busca em todos os campos (14 campos + BLOBs)"
    Write-Host "  .\buscar-sai.ps1 -Termos 'sped contabil','ecd'   OR entre varios termos (substitui -Termo)"
    Write-Host "  .\buscar-sai.ps1 -Termo 'ECD' -PalavraIsolada    Evita match dentro de outras palavras"
    Write-Host "  .\buscar-sai.ps1 -Termo 'sped' -SomenteDescricao Limita a busca a sai_descricao"
    Write-Host "  .\buscar-sai.ps1 -Termo 'INSS' -Tipo NE          Filtra por tipo"
    Write-Host "  .\buscar-sai.ps1 -Termo 'ferias' -Pendentes       So pendentes"
    Write-Host "  .\buscar-sai.ps1 -Termo 'rescisao' -VerPSAIs      Mostra todas as PSAIs (sem agrupar)"
    Write-Host "  .\buscar-sai.ps1 -SAI 12345                       Busca por numero de SAI"
    Write-Host "  .\buscar-sai.ps1 -PSAI 67890                      Busca por numero de PSAI"
    Write-Host "  .\buscar-sai.ps1 -Modulo 'Escrita'                Filtra nomeArea/descricao (ex.: Escrita, Importacao)
  .\buscar-sai.ps1 -Termo 'ICMS' -Areas 'Escrita','Importacao'   Filtra por areas exatas (array)"
    Write-Host "  .\buscar-sai.ps1 -Termo 'FGTS' -Resumido          Saida compacta"
    Write-Host ""
    Write-Host "  EXEMPLO COMBINADO (igual ao do PDF/General):" -ForegroundColor White
    Write-Host "  .\buscar-sai.ps1 -Termos 'SPED Contabil','ECD' -PalavraIsolada -SomenteDescricao ``" -ForegroundColor Gray
    Write-Host "                   -Areas 'Contabilidade','ONVIO CONTABIL' -Max 100" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Parametros:" -ForegroundColor White
    Write-Host "  -Termo 'texto'          Busca um unico termo (modo simples; usa Contains)"
    Write-Host "  -Termos 'a','b'         OR entre varios termos (Contains; substitui -Termo)"
    Write-Host "  -PalavraIsolada         Aplica regex \\b<termo>\\b (evita match dentro de palavras)"
    Write-Host "  -SomenteDescricao       Restringe a busca ao campo sai_descricao"
    Write-Host "  -Tipo NE|SAM|SAL|SAIL   Filtrar por tipo"
    Write-Host "  -Modulo 'nome'          Filtrar por nomeArea/descricao (parcial; ex: 'Escrita', 'Onvio')
  -Areas 'A','B'          Filtrar por multiplas areas exatas (array; ex: 'Escrita','Importacao')"
    Write-Host "  -Pendentes              Somente pendentes"
    Write-Host "  -VerPSAIs               Mostrar todas as PSAIs individuais (padrao: agrupa por SAI)"
    Write-Host "  -VisualizarSai          Usar arquivos SAI resumidos (sem BLOBs)"
    Write-Host "  -Resumido               Saida compacta (1 linha por resultado)"
    Write-Host "  -Max 30                 Limite de resultados (padrao: 30)"
    Write-Host ""
    Write-Host "Comportamento padrao:" -ForegroundColor Yellow
    Write-Host "  Busca nos PSAIs (todos os campos). Agrupa por SAI e mostra"
    Write-Host "  apenas a PSAI mais recente de cada SAI. Se a SAI ja existe,"
    Write-Host "  mostra a SAI. Use -VerPSAIs para ver todas as PSAIs."
    exit 0
}

$baseDir = if ($VisualizarSai) { $saiDir } else { $psaiDir }
$usarFracionado = (Test-Path $baseDir) -and (Get-ChildItem $baseDir -Filter "*.json" -ErrorAction SilentlyContinue)

if ($usarFracionado) {
    $arquivos = @()
    $tiposCarregar = if ($Tipo) { @($Tipo.ToLower()) } else { @("ne","sam","sal","sail") }
    $statusCarregar = if ($Pendentes) { @("pendentes") } else { @("pendentes","liberadas","descartadas") }

    foreach ($t in $tiposCarregar) {
        foreach ($st in $statusCarregar) {
            $arq = Join-Path $baseDir "$t-$st.json"
            if (Test-Path $arq) { $arquivos += $arq }
        }
    }

    Write-Host "Buscando em $($arquivos.Count) arquivo(s) fracionado(s)..." -ForegroundColor Yellow
    $todosRegistros = @()
    foreach ($arq in $arquivos) {
        $sizeMB = [math]::Round((Get-Item $arq).Length / 1MB, 1)
        $nomeArq = Split-Path -Leaf $arq
        Write-Host "  $nomeArq ($($sizeMB)MB)" -ForegroundColor Gray
        $conteudo = Get-Content $arq -Raw -Encoding UTF8 | ConvertFrom-Json
        $todosRegistros += $conteudo.dados
    }
    Write-Host "  $($todosRegistros.Count) registros carregados" -ForegroundColor Green
} else {
    if (-not (Test-Path $cacheCompleto)) {
        Write-Host "ERRO: Nenhum dado encontrado." -ForegroundColor Red
        Write-Host "Rode 'scripts\atualizar-tudo.bat' primeiro."
        exit 1
    }
    Write-Host "JSONs fracionados nao encontrados. Usando cache completo..." -ForegroundColor Yellow
    Write-Host "Carregando (pode demorar ~30s)..."
    $conteudo = Get-Content $cacheCompleto -Raw -Encoding UTF8 | ConvertFrom-Json
    $todosRegistros = $conteudo.dados
    Write-Host "  $($conteudo.totalRegistros) registros carregados" -ForegroundColor Green
}

$resultado = $todosRegistros

# Filtro por numero exato
if ($SAI -ne 0) {
    $resultado = @($resultado | Where-Object { $_.i_sai -eq $SAI })
} elseif ($PSAI -ne 0) {
    $campo = if ($VisualizarSai) { "ultimaPsai" } else { "i_psai" }
    $resultado = @($resultado | Where-Object { $_.$campo -eq $PSAI })
} else {
    # Filtro por termo(s): -Termos (array OR) tem prioridade sobre -Termo (string)
    # Os termos sao normalizados (sem acentos + lowercase) para tolerancia a acentuacao
    $termosBusca = @()
    if ($Termos -and $Termos.Count -gt 0) {
        $termosBusca = @($Termos | Where-Object { $_ -and $_.Trim() } | ForEach-Object { (Remove-Acentos $_).ToLower().Trim() })
    } elseif ($Termo) {
        $termosBusca = @((Remove-Acentos $Termo).ToLower())
    }

    if ($termosBusca.Count -gt 0) {
        # Compilar regex se -PalavraIsolada (uma vez por termo)
        $regexTermos = @()
        if ($PalavraIsolada) {
            foreach ($t in $termosBusca) {
                $escapado = [Regex]::Escape($t)
                $regexTermos += [Regex]::new("\b$escapado\b", [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
            }
        }

        # Funcao local: termo bate em texto?
        # Normaliza acentos do texto antes de comparar.
        function Test-TermoMatch($texto, $idxTermo) {
            $s = SafeStr $texto
            if (-not $s) { return $false }
            $sNorm = (Remove-Acentos $s).ToLower()
            if ($PalavraIsolada) {
                return $regexTermos[$idxTermo].IsMatch($sNorm)
            } else {
                return $sNorm.Contains($termosBusca[$idxTermo])
            }
        }

        $resultado = @($resultado | Where-Object {
            $reg = $_
            # Para cada termo, ver se bate em ALGUM dos campos. OR entre termos.
            $bateAlgumTermo = $false
            for ($i = 0; $i -lt $termosBusca.Count; $i++) {
                if ($termosBusca[$i] -match '^\d+$') {
                    if (Test-NumeroSaiPsai $reg $termosBusca[$i]) { $bateAlgumTermo = $true; break }
                } elseif ($SomenteDescricao) {
                    # Restringe a sai_descricao
                    if (Test-TermoMatch $reg.sai_descricao $i) { $bateAlgumTermo = $true; break }
                } else {
                    if ( (Test-TermoMatch $reg.sai_descricao $i)  -or
                         (Test-TermoMatch $reg.comportamento  $i) -or
                         (Test-TermoMatch $reg.definicao      $i) -or
                         (Test-TermoMatch $reg.psai_descricao $i) -or
                         (Test-TermoMatch $reg.sai_destaque   $i) -or
                         (Test-TermoMatch $reg.psai_destaque  $i) -or
                         (Test-TermoMatch $reg.textoCompleto  $i) -or
                         (Test-TermoMatch $reg.nomeArea       $i) -or
                         (Test-TermoMatch $reg.nomeVersao     $i) -or
                         (Test-TermoMatch $reg.tipoSAI        $i) -or
                         (Test-TermoMatch $reg.gravidade_ne   $i) -or
                         (Test-TermoMatch $reg.situacaoSai    $i) -or
                         (Test-TermoMatch $reg.situacaoPsai   $i) -or
                         (Test-TermoMatch $reg.nivel_alteracao $i)
                    ) { $bateAlgumTermo = $true; break }
                }
            }
            $bateAlgumTermo
        })

        $modoBusca = if ($Termos.Count -gt 0) { "OR entre $($termosBusca.Count) termos" } else { "termo unico" }
        if ($termosBusca.Count -eq 1 -and $termosBusca[0] -match '^\d+$') { $modoBusca += ", numero SAI/PSAI" }
        if ($PalavraIsolada) { $modoBusca += ", palavra isolada" }
        if ($SomenteDescricao) { $modoBusca += ", so descricao" }
        Write-Host "  Filtro de termo aplicado: $modoBusca" -ForegroundColor DarkCyan
    }

    # Filtro por modulo (busca em nomeArea e sai_descricao)
    if ($Modulo) {
        $moduloLower = $Modulo.ToLower()
        $resultado = @($resultado | Where-Object {
            (SafeStr $_.nomeArea).ToLower().Contains($moduloLower) -or
            (SafeStr $_.sai_descricao).ToLower().Contains($moduloLower)
        })
    }

    # Filtro por areas exatas (array de nomeArea; respeita config/analista.json areas do analista)
    if ($Areas.Count -gt 0) {
        $areasLower = $Areas | ForEach-Object { $_.ToLower().Trim() }
        $resultado = @($resultado | Where-Object {
            $nomeAreaLower = (SafeStr $_.nomeArea).ToLower().Trim()
            $areasLower | Where-Object { $nomeAreaLower -eq $_ } | Select-Object -First 1
        })
        Write-Host "  Filtro de areas aplicado: $($Areas -join ', ')" -ForegroundColor DarkCyan
    }

}

# --- DEDUPLICACAO POR SAI (padrao: mostra 1 resultado por SAI) ---
if (-not $VerPSAIs -and -not $VisualizarSai -and $SAI -eq 0 -and $PSAI -eq 0) {
    $porSai = @{}
    foreach ($r in $resultado) {
        $chave = [string]$r.i_sai
        if (-not $porSai.ContainsKey($chave)) {
            $porSai[$chave] = $r
        } else {
            $existente = $porSai[$chave]
            $psaiAtual = if ($r.i_psai) { [int]$r.i_psai } else { 0 }
            $psaiExist = if ($existente.i_psai) { [int]$existente.i_psai } else { 0 }
            if ($r.Liberacao -and -not $existente.Liberacao) {
                $porSai[$chave] = $r
            } elseif ($psaiAtual -gt $psaiExist) {
                $porSai[$chave] = $r
            }
        }
    }
    $totalAntes = $resultado.Count
    $resultado = @($porSai.Values)
    $dedup = $totalAntes - $resultado.Count
    if ($dedup -gt 0) {
        Write-Host "(Agrupado por SAI: $($resultado.Count) SAIs unicas de $totalAntes PSAIs. Use -VerPSAIs para ver todas)" -ForegroundColor DarkYellow
    }
}

$totalResultados = $resultado.Count
Write-Host ""
Write-Host "=== $totalResultados resultado(s) ===" -ForegroundColor Cyan
if ($totalResultados -eq 0) { exit 0 }

$resultado | Select-Object -First $Max | ForEach-Object {
    $urlSai  = Get-UrlSai  $_.i_sai
    $urlPsai = Get-UrlPsai $_.i_psai

    if ($Resumido) {
        # Saida compacta: 1 linha por resultado
        $saiNum = if ($VisualizarSai) { $_.i_sai } else { "$($_.i_sai)/$($_.i_psai)" }
        $status = if ($VisualizarSai) { $_.situacaoSai } else {
            if ($_.Liberacao) { "Lib" } elseif ($_.Descarte) { "Desc" } else { "Pend" }
        }
        $grav = if ($_.gravidade_ne) { $g = SafeStr $_.gravidade_ne; $g.Substring(0, [Math]::Min(4, $g.Length)) } else { "-" }
        $desc = if ($_.sai_descricao) {
            $d = SafeStr $_.sai_descricao; $d.Substring(0, [Math]::Min(80, $d.Length)) -replace "`r|`n", " "
        } else { "-" }
        Write-Host "  $saiNum | $($_.tipoSAI) | $status | $grav | $desc" -ForegroundColor Gray
        if ($urlSai)  { Write-Host "    SAI:  $urlSai"  -ForegroundColor Blue }
        if ($urlPsai) { Write-Host "    PSAI: $urlPsai" -ForegroundColor Blue }
    } elseif ($VisualizarSai) {
        $dt = if ($_.ultimoCadastro) { try { ([datetime]$_.ultimoCadastro).ToString("dd/MM/yyyy") } catch { "-" } } else { "-" }
        $desc = if ($_.sai_descricao) {
            $d = SafeStr $_.sai_descricao; $d.Substring(0, [Math]::Min(120, $d.Length)) -replace "`r|`n", " "
        } else { "-" }
        $urlPsaiUltima = Get-UrlPsai $_.ultimaPsai
        Write-Host ""
        Write-Host "--- SAI $($_.i_sai) ($($_.totalPsais) PSAIs) ---" -ForegroundColor White
        if ($urlSai)        { Write-Host "  SAI:  $urlSai"         -ForegroundColor Blue }
        if ($urlPsaiUltima) { Write-Host "  PSAI: $urlPsaiUltima"  -ForegroundColor Blue }
        Write-Host "  Tipo: $($_.tipoSAI) | Versao: $($_.nomeVersao) | Status: $($_.situacaoSai)" -ForegroundColor Gray
        Write-Host "  Ultima PSAI: $($_.ultimaPsai) | Cadastro: $dt | Gravidade: $($_.gravidade_ne)" -ForegroundColor Gray
        Write-Host "  $desc"
    } else {
        $status = if ($_.Liberacao) { "Liberada" } elseif ($_.Descarte) { "Descartada" } else { "Pendente" }
        $dt = if ($_.CadastroPSAI) { try { ([datetime]$_.CadastroPSAI).ToString("dd/MM/yyyy") } catch { "-" } } else { "-" }
        $desc = if ($_.sai_descricao) {
            $d = SafeStr $_.sai_descricao; $d.Substring(0, [Math]::Min(120, $d.Length)) -replace "`r|`n", " "
        } else { "-" }
        $rotulo = if ($_.Liberacao) { "SAI $($_.i_sai) (PSAI $($_.i_psai) - Liberada)" }
                  elseif ([int]$_.i_psai -eq 0) { "SAI $($_.i_sai) (sem PSAI)" }
                  else { "SAI $($_.i_sai) / PSAI $($_.i_psai)" }
        $area = if ($_.nomeArea) { " | Area: $($_.nomeArea)" } else { "" }
        Write-Host ""
        Write-Host "--- $rotulo ---" -ForegroundColor White
        if ($urlSai)  { Write-Host "  SAI:  $urlSai"  -ForegroundColor Blue }
        if ($urlPsai) { Write-Host "  PSAI: $urlPsai" -ForegroundColor Blue }
        Write-Host "  Tipo: $($_.tipoSAI) | Versao: $($_.nomeVersao) | Status: ${status}${area}" -ForegroundColor Gray
        Write-Host "  Cadastro: $dt | Gravidade: $($_.gravidade_ne)" -ForegroundColor Gray
        Write-Host "  $desc"

        # Highlight de trechos: usa o primeiro termo de -Termos OU o -Termo unico
        $termoHighlight = ""
        if ($Termos -and $Termos.Count -gt 0) { $termoHighlight = $Termos[0] }
        elseif ($Termo) { $termoHighlight = $Termo }
        if ($termoHighlight -and -not $SomenteDescricao) {
            $tl = $termoHighlight.ToLower()
            $camposBLOB = @(
                @{ nome = "comportamento";  valor = $_.comportamento },
                @{ nome = "definicao";      valor = $_.definicao },
                @{ nome = "psai_descricao"; valor = $_.psai_descricao },
                @{ nome = "sai_destaque";   valor = $_.sai_destaque },
                @{ nome = "psai_destaque";  valor = $_.psai_destaque },
                @{ nome = "textoCompleto";  valor = $_.textoCompleto },
                @{ nome = "nomeArea";       valor = $_.nomeArea }
            )
            foreach ($cb in $camposBLOB) {
                $sv = SafeStr $cb.valor
                if ($sv -and $sv.ToLower().Contains($tl)) {
                    $idx = $sv.ToLower().IndexOf($tl)
                    $ini = [Math]::Max(0, $idx - 50)
                    $fim = [Math]::Min($sv.Length, $idx + $termoHighlight.Length + 50)
                    $trecho = $sv.Substring($ini, $fim - $ini) -replace "`r|`n", " "
                    if ($ini -gt 0) { $trecho = "...$trecho" }
                    if ($fim -lt $sv.Length) { $trecho = "${trecho}..." }
                    Write-Host "  >> $($cb.nome): $trecho" -ForegroundColor DarkCyan
                }
            }
        }
    }
}

if ($totalResultados -gt $Max) {
    Write-Host ""
    Write-Host "(Mostrando $Max de $totalResultados. Use -Max $totalResultados para ver todos)" -ForegroundColor DarkYellow
}
