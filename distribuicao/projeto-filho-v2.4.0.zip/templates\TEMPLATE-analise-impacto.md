# Análise de Impacto: [AI-XXX] — [Título]

## Metadados

| Campo | Valor |
|---|---|
| **ID** | AI-XXX |
| **Título** | [Descrição do que está sendo analisado] |
| **Solicitante** | [Nome] |
| **Analista** | [Nome de quem fez a análise] |
| **Data** | AAAA-MM-DD |
| **Origem** | [PSAI-XXXXX / SAI-XXXXX / Mudanca legislativa / Demanda de produto] |

## Contexto da Mudança

> O que está mudando e por quê?

[Escreva aqui]

## Módulos Impactados

| Modulo | Definicoes Afetadas | Tipo de Impacto | Severidade | Acao Necessaria |
|---|---|---|---|---|
| [Modulo] | PSAI-XXXXX, SAI-XXXXX | Direto / Indireto | Alta / Media / Baixa | [Descreva] |

## Detalhamento dos Impactos

### Impacto 1 — [Módulo]

**Definicoes afetadas**: PSAI-XXXXX / SAI-XXXXX
**Descricao**: [O que muda e como afeta]
**Risco**: [O que pode dar errado]
**Mitigacao**: [Como prevenir o risco]

### Impacto 2 — [Módulo]

**Definicoes afetadas**: PSAI-YYYYY / SAI-YYYYY
**Descrição**: [O que muda e como afeta]
**Risco**: [O que pode dar errado]
**Mitigação**: [Como prevenir o risco]

## Conflitos Identificados

| Definicao A | Definicao B | Conflito | Resolucao Sugerida |
|---|---|---|---|
| PSAI-XXXXX | SAI-YYYYY | [Descricao] | [Sugestao] |

## Cronologia de Impacto

> Em que ordem as mudanças devem ser implementadas?

1. [Primeiro: ...]
2. [Depois: ...]
3. [Por último: ...]

## Recomendação Final

> Aprovar a mudança? Com ressalvas? Bloquear?

[Parecer do analista]

## Observações

[Informações adicionais ou "Nenhuma"]
