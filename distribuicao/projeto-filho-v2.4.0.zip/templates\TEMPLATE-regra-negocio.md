﻿# [OBSOLETO] Template de Regra de Negocio

> **Este template foi substituido por:**
> - `TEMPLATE-psai.md` — para pre-analises (PSAI)
> - `TEMPLATE-sai.md` — para definicoes detalhadas (SAI)
>
> Use os novos templates ao criar definicoes.
> Este arquivo e mantido apenas como referencia historica.
